import React from "react";
// ALL BOTS WILL BE DISPLAYED
function BotCollection() {
  // Your code here
  return (
    <div className="ui four column grid">
      <div className="row">
        {/*...and here..*/}
        Collection of all bots
      </div>
    </div>
  );
}

export default BotCollection;
